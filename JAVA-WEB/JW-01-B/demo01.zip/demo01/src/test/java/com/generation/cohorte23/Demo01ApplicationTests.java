package com.generation.cohorte23;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
